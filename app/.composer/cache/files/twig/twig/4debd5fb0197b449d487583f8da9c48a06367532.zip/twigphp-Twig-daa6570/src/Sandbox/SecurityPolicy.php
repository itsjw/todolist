<?php

namespace Twig\Sandbox;

class_exists('Twig_Sandbox_SecurityPolicy');

if (\false) {
    class SecurityPolicy extends \Twig_Sandbox_SecurityPolicy
    {
    }
}
