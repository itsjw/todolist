<?php

namespace Twig;

class_exists('Twig_Parser');

if (\false) {
    class Parser extends \Twig_Parser
    {
    }
}
