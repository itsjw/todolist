<?php

namespace Twig\Node;

class_exists('Twig_NodeCaptureInterface');

if (\false) {
    interface NodeCaptureInterface extends \Twig_NodeCaptureInterface
    {
    }
}
