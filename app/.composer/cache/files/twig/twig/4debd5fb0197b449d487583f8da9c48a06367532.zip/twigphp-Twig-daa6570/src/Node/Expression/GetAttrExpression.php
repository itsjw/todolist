<?php

namespace Twig\Node\Expression;

class_exists('Twig_Node_Expression_GetAttr');

if (\false) {
    class GetAttrExpression extends \Twig_Node_Expression_GetAttr
    {
    }
}
