<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_From');

if (\false) {
    class FromTokenParser extends \Twig_TokenParser_From
    {
    }
}
