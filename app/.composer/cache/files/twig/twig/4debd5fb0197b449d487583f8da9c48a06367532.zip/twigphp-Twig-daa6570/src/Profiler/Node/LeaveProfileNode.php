<?php

namespace Twig\Profiler\Node;

class_exists('Twig_Profiler_Node_LeaveProfile');

if (\false) {
    class LeaveProfileNode extends \Twig_Profiler_Node_LeaveProfile
    {
    }
}
