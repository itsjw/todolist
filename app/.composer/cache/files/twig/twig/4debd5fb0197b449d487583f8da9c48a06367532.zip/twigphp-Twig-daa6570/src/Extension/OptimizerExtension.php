<?php

namespace Twig\Extension;

class_exists('Twig_Extension_Optimizer');

if (\false) {
    class OptimizerExtension extends \Twig_Extension_Optimizer
    {
    }
}
