<?php

namespace Twig\Extension;

class_exists('Twig_Extension_Escaper');

if (\false) {
    class EscaperExtension extends \Twig_Extension_Escaper
    {
    }
}
