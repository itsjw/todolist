<?php

namespace Twig\Node;

class_exists('Twig_Node_SetTemp');

if (\false) {
    class SetTempNode extends \Twig_Node_SetTemp
    {
    }
}
