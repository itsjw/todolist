<?php

namespace Twig\Extension;

class_exists('Twig_Extension_Debug');

if (\false) {
    class DebugExtension extends \Twig_Extension_Debug
    {
    }
}
