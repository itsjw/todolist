<?php

namespace Twig\Extension;

class_exists('Twig_Extension_Core');

if (\false) {
    class CoreExtension extends \Twig_Extension_Core
    {
    }
}
