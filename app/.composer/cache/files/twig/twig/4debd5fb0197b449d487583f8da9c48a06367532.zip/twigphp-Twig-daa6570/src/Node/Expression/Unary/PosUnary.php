<?php

namespace Twig\Node\Expression\Unary;

class_exists('Twig_Node_Expression_Unary_Pos');

if (\false) {
    class PosUnary extends \Twig_Node_Expression_Unary_Pos
    {
    }
}
