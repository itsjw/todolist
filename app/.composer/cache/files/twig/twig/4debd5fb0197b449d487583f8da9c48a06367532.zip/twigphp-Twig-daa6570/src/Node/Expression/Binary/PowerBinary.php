<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary_Power');

if (\false) {
    class PowerBinary extends \Twig_Node_Expression_Binary_Power
    {
    }
}
