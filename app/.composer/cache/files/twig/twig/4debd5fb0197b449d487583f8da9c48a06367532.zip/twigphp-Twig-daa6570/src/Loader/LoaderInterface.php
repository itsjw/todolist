<?php

namespace Twig\Loader;

class_exists('Twig_LoaderInterface');

if (\false) {
    interface LoaderInterface extends \Twig_LoaderInterface
    {
    }
}
