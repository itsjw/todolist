<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser');

if (\false) {
    class AbstractTokenParser extends \Twig_TokenParser
    {
    }
}
