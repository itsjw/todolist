| Q                | A
| ---------------- | -----
| Bug report?      | yes/no
| Feature request? | yes/no
| BC Break report? | yes/no
| RFC?             | yes/no
| Symfony version  | x.y.z

<!--
- Please fill in this template according to your issue.
- For support request or how-tos, visit https://symfony.com/support
- Otherwise, replace this comment by the description of your issue.
-->
