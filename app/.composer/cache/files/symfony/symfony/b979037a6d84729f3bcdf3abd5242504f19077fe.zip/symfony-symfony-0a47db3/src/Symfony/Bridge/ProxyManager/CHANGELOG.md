CHANGELOG
=========

3.3.0
-----

 * [BC BREAK] The `ProxyDumper` class is now final

2.3.0
-----

 * First introduction of `Symfony\Bridge\ProxyManager`
