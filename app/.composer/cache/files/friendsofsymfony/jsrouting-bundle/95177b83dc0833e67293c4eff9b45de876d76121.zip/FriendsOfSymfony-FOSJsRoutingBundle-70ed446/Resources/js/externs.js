/**
 * @fileoverview This file contains some properties which we don't
 * want the compiler to rename.
 */
var externs = {
    tokens: '',
    defaults: '',
    requirements: '',
    hosttokens: '',
    schemes: '',
    methods: ''
};
